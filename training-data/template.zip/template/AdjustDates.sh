sed -i -e 's/2025-01-/2026-01-/g' $(find $(pwd)|grep .csv)
sed -i -e 's/2025-02-/2026-02-/g' $(find $(pwd)|grep .csv)
sed -i -e 's/2025-03-/2026-03-/g' $(find $(pwd)|grep .csv)
sed -i -e 's/2025-04-/2026-04-/g' $(find $(pwd)|grep .csv)
sed -i -e 's/2025-05-/2026-05-/g' $(find $(pwd)|grep .csv)
sed -i -e 's/2025-06-/2026-06-/g' $(find $(pwd)|grep .csv)
sed -i -e 's/2025-07-/2026-07-/g' $(find $(pwd)|grep .csv)
sed -i -e 's/2025-08-/2026-08-/g' $(find $(pwd)|grep .csv)
sed -i -e 's/2025-09-/2026-09-/g' $(find $(pwd)|grep .csv)
sed -i -e 's/2025-10-/2026-10-/g' $(find $(pwd)|grep .csv)
sed -i -e 's/2025-11-/2026-11-/g' $(find $(pwd)|grep .csv)
sed -i -e 's/2025-12-/2026-12-/g' $(find $(pwd)|grep .csv)

rm *csv-e*





